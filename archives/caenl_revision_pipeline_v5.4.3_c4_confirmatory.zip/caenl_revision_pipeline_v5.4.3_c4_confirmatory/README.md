# CÆNL revision pipeline v5.4.3 — C4 confirmatory campaign

This package is the audited successor to C4 calibration-v2. It freezes the
selected C4 settings and runs six paired confirmatory seeds for baseline, fixed
DCR, MACC-Lite, and Full MACC on the IBM L40S.

Start with `docs/C4_CONFIRMATORY_V2_RUNBOOK.md`.

Key safeguards:

- one dataset/campaign at a time;
- all active data and results under `/mnt/caenl`;
- 100M training tokens per run;
- six paired seeds (301--306);
- calibration jobs excluded from confirmatory inference;
- strict cross-modal significance validation;
- deterministic source-snapshot fingerprint recorded in every campaign;
- automatic result archive and checksum.
