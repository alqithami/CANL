From this extracted directory, install NumPy/SciPy and run:
  python3 results/caenl-solidification-v1/reconstruct_stats.py
  python3 analysis/completed/reproduce.py

These reconstruct separate study families from saved numeric records, not model predictions. Read each release README and PROVENANCE file.
