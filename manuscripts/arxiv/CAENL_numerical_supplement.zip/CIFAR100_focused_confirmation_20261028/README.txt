CIFAR-100 focused confirmation — 28 October 2026

This supplement retains all 160 official-test score records, all 54 development outcomes, the three planned contrasts, descriptive costs, source bindings and CPU reconstruction code. None of the primary comparisons establishes superiority after Holm correction.

All earlier numerical-supplement members remain unchanged. The additional 5,000 labeled development images are separate from each gradient-training budget. The four-method confirmation does not establish results against SupCon or NONL, active-learning gains, annotation savings, robustness or mechanism.

Immutable public release:
https://github.com/alqithami/CANL/tree/b7997451606151344a155625127ed15db956ada2/results/caenl-cifar100-focused-v1

See analysis/cifar100_focused/README.md for the CPU reconstruction command. Exported-record reconstruction is distinct from independently repeating model training or official-test inference.
